package com.challenge.ulangch4

class LifeCycle {
}